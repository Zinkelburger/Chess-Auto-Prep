#pragma once

#include <string>
#include <string_view>

// Resolves an ONNX model path from an explicit path or by scanning default model directories.
std::string resolveModelPath(const std::string& explicitPath = "");

// Returns the path to the latest ONNX file in the given directory, or an empty string if none found.
std::string findLatestOnnxFile(const std::string& directory);

// Converts an ONNX path to a TensorRT engine path
// Format: [model_name]_[precision]_[batch_size]_[device]_[version].engine
std::string getEnginePath(const std::string& onnxPath, const std::string& precision, 
                          int batchSize, int deviceId, const std::string& version);

// Returns a deterministic signature of file contents and build configuration.
std::string computeFileSignature(const std::string& path, std::string_view buildDescriptor);

// Explicit UTF-8 conversions avoid the Windows ANSI code page.
#include <filesystem>
inline std::string pathAsUtf8(const std::filesystem::path& path) {
    const auto value = path.u8string();
    return std::string(value.begin(), value.end());
}
inline std::filesystem::path pathFromUtf8(const std::string& value) {
    return std::filesystem::path(std::u8string(value.begin(), value.end()));
}
