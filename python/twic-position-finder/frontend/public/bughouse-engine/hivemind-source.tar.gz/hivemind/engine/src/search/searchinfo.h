#pragma once

#include <atomic>
#include <chrono>
#include <algorithm>
#include <mutex>

/**
 * @brief Thread-safe search statistics tracking.
 * 
 * Uses atomic operations for counters to support multi-threaded MCTS.
 * Includes time management state for early stopping and time extension.
 */
struct SearchInfo {
    std::chrono::time_point<std::chrono::steady_clock> start;
    std::atomic<int64_t> startTimeMs_{0};
    int moveTime; 
    std::atomic<int> nodes{0};
    std::atomic<int> maxDepth{0};
    std::atomic<int> sameBatchCollisions{0};
    std::atomic<int> reservationCollisions{0};
    
    // Time management state
    mutable std::mutex timeMutex_;
    float overallNPS_ = 0.0f;          // Running average of nodes per second
    int timeExtensionCount_ = 0;       // Number of time extensions applied
    std::atomic<int> effectiveMoveTime_{0};  // Current move time (may be extended)
    std::atomic<int> hardLimitMs_{0};  // Extensions may never cross this (0 = none)
    bool inGame_ = false;              // Whether this is a timed game

    // Constructor initializes the start time and move time.
    SearchInfo(std::chrono::time_point<std::chrono::steady_clock> startTime, int moveTime)
        : start(startTime), moveTime(moveTime), effectiveMoveTime_(moveTime) {
        startTimeMs_.store(std::chrono::duration_cast<std::chrono::milliseconds>(
            startTime.time_since_epoch()).count(), std::memory_order_relaxed);
    }
    
    ~SearchInfo() = default;

    // Resets search start time (used on ponderhit to measure turn duration).
    void reset_start_time() {
        std::lock_guard<std::mutex> lock(timeMutex_);
        auto now = std::chrono::steady_clock::now();
        start = now;
        startTimeMs_.store(std::chrono::duration_cast<std::chrono::milliseconds>(
            now.time_since_epoch()).count(), std::memory_order_release);
        timeExtensionCount_ = 0;
    }

    // Returns the original move time.
    int get_move_time() const {
        return moveTime; 
    }
    
    // Returns the effective move time (may be extended).
    int get_effective_move_time() const {
        return effectiveMoveTime_.load(std::memory_order_relaxed);
    }
    
    // Returns remaining time in milliseconds.
    double remaining_time() const {
        std::lock_guard<std::mutex> lock(timeMutex_);
        return std::max(
            0.0,
            effectiveMoveTime_.load(std::memory_order_relaxed) - elapsed_unlocked());
    }

    // Returns the elapsed time in milliseconds since start (lock-free).
    double elapsed_unlocked() const {
        int64_t startMs = startTimeMs_.load(std::memory_order_relaxed);
        int64_t nowMs = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
        return static_cast<double>(std::max<int64_t>(0, nowMs - startMs));
    }

    // Returns the elapsed time in milliseconds since start.
    double elapsed() const {
        return elapsed_unlocked();
    }

    inline int get_nodes_searched() const {
        return nodes.load(std::memory_order_relaxed); 
    }

    inline int get_max_depth() const {
        return maxDepth.load(std::memory_order_relaxed); 
    }

    inline int get_collisions() const {
        return sameBatchCollisions.load(std::memory_order_relaxed)
            + reservationCollisions.load(std::memory_order_relaxed);
    }

    inline int get_same_batch_collisions() const {
        return sameBatchCollisions.load(std::memory_order_relaxed);
    }

    inline int get_reservation_collisions() const {
        return reservationCollisions.load(std::memory_order_relaxed);
    }

    // Atomically increments the node counter.
    inline void increment_nodes(int value) {
        nodes.fetch_add(value, std::memory_order_relaxed); 
    }

    // Atomically updates the maximum depth encountered.
    inline void set_max_depth(int depth) {
        int current = maxDepth.load(std::memory_order_relaxed);
        while (depth > current && 
               !maxDepth.compare_exchange_weak(current, depth, std::memory_order_relaxed));
    }

    // Atomically increments the collision counter.
    inline void increment_same_batch_collisions(int value = 1) {
        sameBatchCollisions.fetch_add(value, std::memory_order_relaxed);
    }

    inline void increment_reservation_collisions(int value = 1) {
        reservationCollisions.fetch_add(value, std::memory_order_relaxed);
    }
    
    // =========================================================================
    // Time Management Methods
    // =========================================================================
    
    /**
     * @brief Update the running NPS average.
     * Called periodically during search.
     */
    void update_nps() {
        std::lock_guard<std::mutex> lock(timeMutex_);
        double elapsedSec = elapsed_unlocked() / 1000.0;
        if (elapsedSec > 0.1) {  // Need at least 100ms for reliable NPS
            float currentNPS = static_cast<float>(nodes.load(std::memory_order_relaxed) / elapsedSec);
            if (overallNPS_ == 0.0f) {
                overallNPS_ = currentNPS;
            } else {
                // Exponential moving average
                overallNPS_ = 0.9f * overallNPS_ + 0.1f * currentNPS;
            }
        }
    }
    
    /**
     * @brief Get the current NPS estimate.
     */
    float get_nps() const {
        std::lock_guard<std::mutex> lock(timeMutex_);
        return overallNPS_;
    }
    
    /**
     * @brief Set whether this is an in-game search with time controls.
     */
    void set_in_game(bool inGame) {
        std::lock_guard<std::mutex> lock(timeMutex_);
        inGame_ = inGame;
    }
    
    /**
     * @brief Set an absolute ceiling that time extensions may not cross.
     *
     * A UCI `go movetime` is the whole allocation for the move, not a target
     * to overshoot, so a search given one caps its extensions at it. Zero
     * leaves extensions unbounded.
     */
    void set_hard_limit(int hardLimitMs) {
        hardLimitMs_.store(hardLimitMs, std::memory_order_relaxed);
    }

    /** Returns the extension ceiling, or 0 when extensions are unbounded. */
    int get_hard_limit() const {
        return hardLimitMs_.load(std::memory_order_relaxed);
    }

    /**
     * @brief Try to extend the move time.
     * @param factor Multiplication factor for remaining time
     * @param maxExtensions Maximum number of extensions allowed
     * @return true if extension was applied, false if limit reached
     */
    bool try_extend_time(float factor, int maxExtensions) {
        std::lock_guard<std::mutex> lock(timeMutex_);
        if (timeExtensionCount_ >= maxExtensions) {
            return false;
        }
        
        const int effectiveMoveTime =
            effectiveMoveTime_.load(std::memory_order_relaxed);
        double remaining = effectiveMoveTime - elapsed_unlocked();
        if (remaining <= 0) {
            return false;
        }
        
        int extension = static_cast<int>(remaining * (factor - 1.0f));
        const int hardLimit = hardLimitMs_.load(std::memory_order_relaxed);
        if (hardLimit > 0) {
            extension = std::min(extension, hardLimit - effectiveMoveTime);
        }
        if (extension <= 0) {
            return false;
        }
        effectiveMoveTime_.store(
            effectiveMoveTime + extension, std::memory_order_relaxed);
        timeExtensionCount_++;
        return true;
    }
    
    /**
     * @brief Get the number of time extensions applied.
     */
    int get_extension_count() const {
        std::lock_guard<std::mutex> lock(timeMutex_);
        return timeExtensionCount_;
    }
};
