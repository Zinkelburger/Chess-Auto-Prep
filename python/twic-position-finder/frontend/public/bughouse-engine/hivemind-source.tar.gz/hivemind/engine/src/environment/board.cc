#include "environment/board.h"

#include <stdexcept>

// String containing whitespace characters.
const std::string WHITESPACE = " \n\r\t\f\v";

// Removes leading whitespace from the input string.
std::string ltrim(const std::string &s) {
    size_t start = s.find_first_not_of(WHITESPACE);
    return (start == std::string::npos) ? "" : s.substr(start);
}
 
// Removes trailing whitespace from the input string.
std::string rtrim(const std::string &s) {
    size_t end = s.find_last_not_of(WHITESPACE);
    return (end == std::string::npos) ? "" : s.substr(0, end + 1);
}
 
// Trims both leading and trailing whitespace.
std::string trim(const std::string &s) {
    return rtrim(ltrim(s));
}

// Sets the board state using a FEN string.
// The FEN is expected to have two parts separated by a '|' character.
void Board::set(std::string fen) {
    std::stringstream ss(fen);
    std::string line; 
    getline(ss, line, '|');
    line = trim(line); 

    states[0] = Stockfish::StateListPtr(new std::deque<Stockfish::StateInfo>(1));
    pos[0]->set(Stockfish::variants.find("bughouse")->second, line, false, &states[0]->back(), Stockfish::Threads.main());
    clear_position_history(0);
    record_position(0);
    moveHistory[0].clear();
    
    getline(ss, line, '|');
    line = trim(line);
    
    states[1] = Stockfish::StateListPtr(new std::deque<Stockfish::StateInfo>(1));
    pos[1]->set(Stockfish::variants.find("bughouse")->second, line, false, &states[1]->back(), Stockfish::Threads.main());
    clear_position_history(1);
    record_position(1);
    moveHistory[1].clear();
}

// Default constructor: initializes the board positions and sets them to the starting FEN.
Board::Board() {
    pos[0] = std::unique_ptr<Stockfish::Position>(new Stockfish::Position);
    pos[1] = std::unique_ptr<Stockfish::Position>(new Stockfish::Position);

    states[0] = Stockfish::StateListPtr(new std::deque<Stockfish::StateInfo>(1));
    pos[0]->set(Stockfish::variants.find("bughouse")->second, startingFen, false, &states[0]->back(), Stockfish::Threads.main());

    states[1] = Stockfish::StateListPtr(new std::deque<Stockfish::StateInfo>(1));
    pos[1]->set(Stockfish::variants.find("bughouse")->second, startingFen, false, &states[1]->back(), Stockfish::Threads.main());
    
    // Initialize position history with starting positions
    record_position(0);
    record_position(1);
}

// Copy constructor: copies state history and reinitializes positions from the provided board.
Board::Board(const Board& board) {
    pos[0] = std::unique_ptr<Stockfish::Position>(new Stockfish::Position);
    pos[1] = std::unique_ptr<Stockfish::Position>(new Stockfish::Position);

    // A copied search board only needs the current Position state: all moves
    // made on the copy are undone back to this root, never into the source's
    // StateInfo chain. Rebuilding that entire deque was pure allocation/copy
    // overhead in the hottest setup path.
    states[0] = Stockfish::StateListPtr(new std::deque<Stockfish::StateInfo>(1));
    states[1] = Stockfish::StateListPtr(new std::deque<Stockfish::StateInfo>(1));

    pos[0]->set(Stockfish::variants.find("bughouse")->second, board.pos[0]->fen(false, true), false, &states[0]->back(), Stockfish::Threads.main());
    pos[1]->set(Stockfish::variants.find("bughouse")->second, board.pos[1]->fen(false, true), false, &states[1]->back(), Stockfish::Threads.main());
    
    // Copy position history
    positionHistory[0] = board.positionHistory[0];
    positionHistory[1] = board.positionHistory[1];
    repetitionCounts[0] = board.repetitionCounts[0];
    repetitionCounts[1] = board.repetitionCounts[1];
    repetitionFingerprint[0] = board.repetitionFingerprint[0];
    repetitionFingerprint[1] = board.repetitionFingerprint[1];
    moveHistory[0] = board.moveHistory[0];
    moveHistory[1] = board.moveHistory[1];
}

// Executes a move on the board and updates the corresponding state.
// Also adds a piece to the opponent's hand if necessary.
void Board::push_move(int board_num, Stockfish::Move move) {
    states[board_num]->emplace_back();
    pos[board_num]->do_move(move, states[board_num]->back());
    Stockfish::Piece p = states[board_num]->back().pieceToHand; 
    if (p) {
        pos[1 - board_num]->add_to_hand_with_key(p);
    }
    // Record position for repetition detection
    record_position(board_num);
    moveHistory[board_num].push_back(move);
}

bool Board::is_legal_move(int board_num, Stockfish::Move move) const {
    return move == Stockfish::MOVE_NONE
        || Stockfish::MoveList<Stockfish::LEGAL>(*pos[board_num]).contains(move);
}

bool Board::has_any_legal_move(int board_num) const {
    const Stockfish::Position& position = *pos[board_num];
    if (position.is_immediate_game_end()) {
        return false;
    }

    // In bughouse an available drop is immediately legal when the king is not
    // in check. Test the actual drop regions so pawn back-rank restrictions are
    // respected without invoking move generation.
    if (!position.checkers()
        && position.piece_drops()
        && position.count_in_hand(position.side_to_move(), Stockfish::ALL_PIECES) > 0) {
        const Stockfish::Color side = position.side_to_move();
        const Stockfish::Bitboard emptySquares = position.board_bb() & ~position.pieces();
        for (Stockfish::PieceType pieceType : position.piece_types()) {
            if (position.count_in_hand(side, pieceType) > 0
                && (position.drop_region(side, pieceType) & emptySquares)) {
                return true;
            }
        }
    }

    // Avoid LEGAL move generation, which checks and compacts every candidate.
    // We only need one legal, non-virtual candidate.
    Stockfish::ExtMove candidates[Stockfish::MAX_MOVES];
    Stockfish::ExtMove* end = position.checkers()
        ? Stockfish::generate<Stockfish::EVASIONS>(position, candidates)
        : Stockfish::generate<Stockfish::NON_EVASIONS>(position, candidates);
    for (Stockfish::ExtMove* candidate = candidates; candidate != end; ++candidate) {
        if (position.legal(*candidate) && !position.virtual_drop(*candidate)) {
            return true;
        }
    }
    return false;
}

// Reverts the last move on the board and updates the state.
// Also removes a piece from the opponent's hand if necessary.
void Board::pop_move(int board_num) {
    Stockfish::Move m = states[board_num]->back().move; 
    Stockfish::Piece p = states[board_num]->back().pieceToHand; 
    if (p) {
        pos[1 - board_num]->remove_from_hand_with_key(p);
    }
    pos[board_num]->undo_move(m); 
    states[board_num]->pop_back();
    // Remove position from history
    unrecord_position(board_num);
    if (!moveHistory[board_num].empty()) {
        moveHistory[board_num].pop_back();
    }
}

// Returns a list of legal moves for the specified board index.
std::vector<Stockfish::Move> Board::legal_moves(int board_num) {
    std::vector<Stockfish::Move> legal_moves;
    for (const Stockfish::ExtMove& move : Stockfish::MoveList<Stockfish::LEGAL>(*pos[board_num])) {
        legal_moves.emplace_back(move);
    }
    return legal_moves;
}

// Returns a list of legal moves for the specified side by checking both boards.
std::vector<std::pair<int, Stockfish::Move>> Board::legal_moves(Stockfish::Color side, bool teamHasTimeAdvantage) {
    std::vector<std::pair<int, Stockfish::Move>> moves;

    // If checkmate, return an empty move list.
    if (is_checkmate(side, teamHasTimeAdvantage)) {
        return {};
    }
    
    if (pos[0]->side_to_move() == side) {
        for (const Stockfish::ExtMove& move : Stockfish::MoveList<Stockfish::LEGAL>(*pos[0])) {
            moves.emplace_back(0, move);
        }
    }

    if (pos[1]->side_to_move() == ~side) {
        for (const Stockfish::ExtMove& move : Stockfish::MoveList<Stockfish::LEGAL>(*pos[1])) {
            moves.emplace_back(1, move);
        }
    }
    return moves;
}

// Determines if the board is in checkmate for the given side in bughouse.
// In bughouse, checkmate is more complex because partner captures can provide
// pieces to drop and block a check. We must verify that:
// 1. The player has no legal moves (including drops with current pieces in hand)
// 2. The partner cannot capture any piece that could be used to block the check
bool Board::is_checkmate(Stockfish::Color side,
                         bool teamHasTimeAdvantage,
                         LegalMoveCache* legalMoveCache,
                         bool assumePartnerCanBlock) {
    const bool isOnTurnOnA = pos[BOARD_A]->side_to_move() == side;
    const bool isOnTurnOnB = pos[BOARD_B]->side_to_move() == ~side;

    LegalMoveCache localLegalMoveCache;
    LegalMoveCache& cache = legalMoveCache ? *legalMoveCache : localLegalMoveCache;
    auto has_legal_move = [&](int boardNum) {
        if (!cache[boardNum].has_value()) {
            cache[boardNum] = has_any_legal_move(boardNum);
        }
        return *cache[boardNum];
    };

    // Check Board A (where 'side' plays)
    if (isOnTurnOnA && pos[BOARD_A]->checkers() && !has_legal_move(BOARD_A)) {
        // No legal moves - but can partner provide a blocking piece?
        if (!can_partner_provide_blocking_piece(
                BOARD_A, side, teamHasTimeAdvantage, assumePartnerCanBlock)) {
            return true;
        }
    }

    // Check Board B (where partner of 'side' plays, so opponent color is ~side)
    if (isOnTurnOnB && pos[BOARD_B]->checkers() && !has_legal_move(BOARD_B)) {
        // No legal moves - but can partner provide a blocking piece?
        if (!can_partner_provide_blocking_piece(
                BOARD_B, ~side, teamHasTimeAdvantage, assumePartnerCanBlock)) {
            return true;
        }
    }

    // If the team has no legal move, it loses unless time advantage makes
    // double-sit legal. Double-sit is still forbidden when both boards are on turn.
    if (isOnTurnOnA || isOnTurnOnB) {
        const bool hasMovesOnA = isOnTurnOnA && has_legal_move(BOARD_A);
        const bool hasMovesOnB = isOnTurnOnB && has_legal_move(BOARD_B);
        if (!hasMovesOnA && !hasMovesOnB
            && (!teamHasTimeAdvantage || (isOnTurnOnA && isOnTurnOnB))) {
            return true;
        }
    }

    return false;
}

// Helper function to check if partner can capture a piece that would allow blocking the check.
// board_in_check: the board index where the player is in check (0 or 1)
// checked_side: the color of the player being checked on that board
// teamHasTimeAdvantage: if true, partner may be able to capture in the future even if not their turn
bool Board::can_partner_provide_blocking_piece(int board_in_check, Stockfish::Color checked_side, bool teamHasTimeAdvantage, bool assumePartnerCanBlock) {
    int partner_board = (board_in_check == BOARD_A) ? BOARD_B : BOARD_A;
    Stockfish::Color partner_side = ~checked_side;  // Partner plays opposite color
    
    // Check if it's currently partner's turn
    bool is_partner_turn = (pos[partner_board]->side_to_move() == partner_side);
    
    // If it's not partner's turn and we don't have time advantage, they can't help
    // But if we have time advantage, they might capture something in the future
    if (!is_partner_turn && !teamHasTimeAdvantage && !assumePartnerCanBlock) {
        return false;
    }
    
    // Get the king square and checker for the board in check
    Stockfish::Square ksq = pos[board_in_check]->square<Stockfish::KING>(checked_side);
    Stockfish::Bitboard checkers = pos[board_in_check]->checkers();
    
    // Double check - can only escape by king move, partner pieces won't help
    if (Stockfish::more_than_one(checkers)) {
        return false;
    }
    
    Stockfish::Square checker_sq = Stockfish::lsb(checkers);
    
    // Get squares between king and checker (where a drop could block)
    // For leaper attacks (knights), there are no blocking squares
    Stockfish::Bitboard blocking_squares = Stockfish::between_bb(ksq, checker_sq);
    
    // Knight, pawn, and king checks cannot be blocked by interposition
    // (between_bb returns empty for adjacent or knight-distance squares)
    if (!blocking_squares) {
        return false;
    }
    
    // Check if any blocking square is empty (available for a drop)
    Stockfish::Bitboard occupied = pos[board_in_check]->pieces();
    Stockfish::Bitboard available_blocks = blocking_squares & ~occupied;
    
    // If there are no empty blocking squares, a drop can't help
    if (!available_blocks) {
        return false;
    }
    
    // Check if there's at least one blocking square valid for pawns (ranks 2-7)
    Stockfish::Bitboard pawn_valid_blocks = available_blocks & ~(Stockfish::Rank1BB | Stockfish::Rank8BB);
    
    auto has_useful_capture = [&](Board& candidateBoard) {
        Stockfish::MoveList<Stockfish::LEGAL> partner_moves(*candidateBoard.pos[partner_board]);

        for (const Stockfish::ExtMove& ext_move : partner_moves) {
            Stockfish::Move move = ext_move;
            Stockfish::Square to = Stockfish::to_sq(move);
            Stockfish::Piece captured = Stockfish::type_of(move) == Stockfish::EN_PASSANT 
                ? Stockfish::make_piece(~partner_side, Stockfish::PAWN) 
                : candidateBoard.pos[partner_board]->piece_on(to);

            if (captured == Stockfish::NO_PIECE) {
                continue;
            }

            Stockfish::PieceType captured_type =
                (candidateBoard.pos[partner_board]->promotedPieces & to)
                    ? Stockfish::PAWN
                    : Stockfish::type_of(captured);

            if (captured_type == Stockfish::PAWN) {
                if (pawn_valid_blocks) {
                    return true;
                }
            } else {
                return true;
            }
        }
        return false;
    };

    // Every test up to here reads the checked board's geometry alone, so this
    // is the point where the answer would start to depend on the partner
    // board. A caller that asked for the blockable-by-assumption model stops
    // here with "yes".
    if (assumePartnerCanBlock) {
        return true;
    }

    if (is_partner_turn) {
        return has_useful_capture(*this);
    }

    // With time advantage the checked team may wait, but the opponent chooses the
    // intervening move. A future blocker is guaranteed only if every reply leaves
    // the partner an immediate useful capture.
    if (teamHasTimeAdvantage) {
        Stockfish::MoveList<Stockfish::LEGAL> opponent_moves(*pos[partner_board]);
        if (!opponent_moves.size()) {
            return false;
        }

        // MoveList holds its own copy of the generated moves, so probing each
        // reply with make/unmake on this board is safe - and far cheaper than
        // copying the whole Board once per reply, which this predicate does for
        // every candidate move of every mate scan.
        for (const Stockfish::ExtMove& opponentMove : opponent_moves) {
            push_move(partner_board, opponentMove);
            const bool partnerCanCapture = has_useful_capture(*this);
            pop_move(partner_board);
            if (!partnerCanCapture) {
                return false;
            }
        }
        return true;
    }

    return false;
}

void Board::make_moves(Stockfish::Move moveA, Stockfish::Move moveB) {
#ifndef NDEBUG
    if (!is_legal_move(BOARD_A, moveA) || !is_legal_move(BOARD_B, moveB)) {
        throw std::logic_error(
            "Search tree supplied an illegal joint action (A="
            + std::to_string(static_cast<uint32_t>(moveA))
            + ", B=" + std::to_string(static_cast<uint32_t>(moveB)) + ")");
    }
#endif

    auto apply_move = [&](int boardNum, Stockfish::Move move) {
        if (move == Stockfish::MOVE_NONE) {
            return;
        }
        states[boardNum]->emplace_back();
        pos[boardNum]->do_move(move, states[boardNum]->back());
        Stockfish::Piece p = states[boardNum]->back().pieceToHand;
        if (p) {
            pos[1 - boardNum]->add_to_hand_with_key(p);
        }
        record_position(boardNum);
        moveHistory[boardNum].push_back(move);
    };

    apply_move(BOARD_A, moveA);
    apply_move(BOARD_B, moveB);
}

void Board::unmake_moves(Stockfish::Move moveA, Stockfish::Move moveB) {
    auto undo_move = [&](int boardNum, Stockfish::Move move) {
        if (move == Stockfish::MOVE_NONE) {
            return;
        }
        Stockfish::Piece p = states[boardNum]->back().pieceToHand;
        if (p) {
            pos[1 - boardNum]->remove_from_hand_with_key(p);
        }
        pos[boardNum]->undo_move(move);
        states[boardNum]->pop_back();
        unrecord_position(boardNum);
        moveHistory[boardNum].pop_back();
    };

    undo_move(BOARD_B, moveB);
    undo_move(BOARD_A, moveA);
}
