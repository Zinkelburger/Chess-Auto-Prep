Hivemind browser source at 5508ba9daf4164e48a8a8a9b39e101efdc60e97a
https://github.com/Zinkelburger/hivemind.git

Install and activate Emscripten 4.0.15. From this extracted directory:
emcmake cmake -S browser -B build -DHIVEMIND_SOURCE="$PWD/hivemind" -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 2

Outputs: build/hivemind.mjs and build/hivemind.wasm.
Browser adapters are part of Chess Auto Prep, under AGPL-3.0.
