/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2022 The Stockfish developers (see AUTHORS file)

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef SEARCH_H_INCLUDED
#define SEARCH_H_INCLUDED

#include <vector>

#include "misc.h"
#include "movepick.h"
#include "types.h"

namespace Stockfish {

class Position;

namespace Search {

/// Threshold used for countermoves based pruning
constexpr int CounterMovePruneThreshold = 0;


/// Stack struct keeps track of the information we need to remember from nodes
/// shallower and deeper in the tree during the search. Each search thread has
/// its own array of Stack objects, indexed by the current ply.

struct Stack {
  Move* pv;
  PieceToHistory* continuationHistory;
  int ply;
  Move currentMove;
  Move excludedMove;
  Move killers[2];
  Value staticEval;
  int statScore;
  int moveCount;
  bool inCheck;
  bool ttPv;
  bool ttHit;
  int doubleExtensions;
};


/// RootMove struct is used for moves at the root of the tree. For each root move
/// we store a score and a PV (really a refutation in the case of moves which
/// fail low). Score is normally set at -VALUE_INFINITE for all non-pv moves.

struct RootMove {

  explicit RootMove(Move m) : pv(1, m) {}
  bool extract_ponder_from_tt(Position& pos);
  bool operator==(const Move& m) const { return pv[0] == m; }
  bool operator<(const RootMove& m) const { // Sort in descending order
    return m.score != score ? m.score < score
                            : m.previousScore < previousScore;
  }

  Value score = -VALUE_INFINITE;
  Value previousScore = -VALUE_INFINITE;
  int selDepth = 0;
  int tbRank = 0;
  Value tbScore;
  std::vector<Move> pv;
};

typedef std::vector<RootMove> RootMoves;


/// LimitsType struct stores information sent by GUI about available time to
/// search the current move, maximum depth/time, or if we are in analysis mode.

struct LimitsType {

  LimitsType() { // Init explicitly due to broken value-initialization of non POD in MSVC
    time[WHITE] = time[BLACK] = inc[WHITE] = inc[BLACK] = npmsec = movetime = TimePoint(0);
    movestogo = depth = mate = perft = infinite = 0;
    nodes = 0;
  }

  bool use_time_management() const {
    return time[WHITE] || time[BLACK];
  }

  std::vector<Move> searchmoves, banmoves;
  TimePoint time[COLOR_NB], inc[COLOR_NB], npmsec, movetime, startTime;
  int movestogo, depth, mate, perft, infinite;
  int64_t nodes;
};

extern LimitsType Limits;

/// HypeBeast hooks. Both flags are false unless the HypeBeast controller sets
/// them around a search, so upstream output and behaviour are unchanged.
struct HBHooks {
  bool capture = false; // store the result in HBResult instead of printing bestmove
  bool silent  = false; // suppress all search output (child searches)
  size_t multiPV = 0;   // >0: MultiPV for this search instead of the UCI option
};

struct HBSearchResult {
  bool  rootMovesEmpty = false;
  Value terminalValue = VALUE_NONE;     // set when there are no root moves
  Move  finalMove = MOVE_NONE;          // what upstream would play
  Move  ponderMove = MOVE_NONE;
  Value finalScore = -VALUE_INFINITE;   // rootMoves[0].score at the end (may be partial)
  Value finalAlpha = -VALUE_INFINITE;   // root window of the last root search
  Value finalBeta = VALUE_INFINITE;
  Depth completedDepth = 0;
  Value exactScore = -VALUE_INFINITE;   // score of the last completed iteration
  std::vector<Move> exactPV;            // PV of the last completed iteration
  int   selDepth = 0;
  uint64_t nodes = 0;
  // Exact (move, score) of every MultiPV line of the last completed iteration
  std::vector<std::pair<Move, Value>> lines;
  std::vector<std::vector<Move>> linePVs; // PV of every line, same order
  std::vector<Move> rootOrder;          // first root moves in final order
};

extern HBHooks HBHook;
extern HBSearchResult HBResult;

void init();
void clear();

} // namespace Search

} // namespace Stockfish

#endif // #ifndef SEARCH_H_INCLUDED
